
public class DSA4Q5 {
	public static int arrangeCoins(int n) {
        int row = 0;
        int remainingCoins = n;

        while (remainingCoins >= row + 1) {
            row++;
            remainingCoins -= row;
        }

        return row;
    }
	public static void main(String[] args) {
		  int n = 5;

	        int result = arrangeCoins(n);
	        System.out.println(result);
	}

}



